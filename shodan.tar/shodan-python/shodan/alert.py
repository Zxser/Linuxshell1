class Alert:
    def __init__(self):
        self.id = None
        self.name = None
        self.api_key = None
        self.filters = None
        self.credits = None
        self.created = None
        self.expires = None
