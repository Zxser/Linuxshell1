from shodan.api import WebAPI
from shodan.client import Shodan
from shodan.exception import APIError
