#!/bin/bash
##robert yu
##centos 6
##LINUX安全检查脚本，安全检查基线

#  LINUX安全检查脚本，安全检查基线，可以参考这个项目
#  https://github.com/ppabc/security_check
#  https://github.com/ppabc/security_check/blob/master/checklinux2.0/checklinux.sh