#!/bin/bash
##robert yu
##centos 6
##boyurl是一个通过PHP来远程执行shell脚本工具。整个程序只有两个文件，一个PHP文件，一个shell安装脚本，易于使用和安装。

#  boyurl是一个通过PHP来远程执行shell脚本工具。整个程序只有两个文件，一个PHP文件，一个shell安装脚本，易于使用和安装。
#  https://github.com/aqzt/boyurl
#  使用文档： http://bbs.51cto.com/thread-1476687-1.html    https://ppabc.cn/1321.html